function walk(){
    console.log("hey I'm walking")
}

function attack(){
    console.log('hey i attacked stuff')
}




module.exports = { 
    walk: walk,
    attack: attack
}