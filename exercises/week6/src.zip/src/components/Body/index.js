import React from 'react';

const Body = () => {
    return (
        <div>I'm the body</div>
    )
}

export default Body; 